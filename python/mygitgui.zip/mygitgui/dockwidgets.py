#!/usr/bin/env python


# This is only needed for Python v2 but is harmless for Python v3.
import sip
sip.setapi('QString', 2)

import os
from PyQt4 import QtCore, QtGui

try:
    import dockwidgets_rc3
except ImportError:
    import dockwidgets_rc2


class MainWindow(QtGui.QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.textEdit = QtGui.QTextEdit()
        self.setCentralWidget(self.textEdit)

        self.initData()
        self.createActions()
        self.createMenus()
        self.createDockWindows()

        self.setWindowTitle("My Git Gui")

    def initData(self):
        #default history length is 100
        self.loglength=1000
        self.loadsha1AndInfo()

    def loadsha1AndInfo(self):
        logsha1='git log --pretty=format:\"%H\" -' + str(self.loglength) + " ."
        output = os.popen(logsha1);
        self.sha1=[]
        for line in output:
            line=line.strip('\n')
            self.sha1.append(line)

        loginfo='git log --pretty=format:\"%s\" -' + str(self.loglength) + " ."
        output = os.popen(loginfo);
        self.info=[]
        for line in output:
            line=line.strip('\n')
            self.info.append(line)



    def gitLogShow(self, index):
        if not index:
            return

        self.textEdit.clear()
        #self.textEdit.setColor(QtCore.Qt.red)
        cursor = self.textEdit.textCursor()
        cursor.movePosition(QtGui.QTextCursor.Start)

        textFormat = QtGui.QTextCharFormat()
        redText = QtGui.QTextCharFormat()
        redText.setForeground(QtCore.Qt.red)
        greenText = QtGui.QTextCharFormat()
        greenText.setForeground(QtCore.Qt.darkGreen)
        blueText = QtGui.QTextCharFormat()
        blueText.setForeground(QtCore.Qt.blue)
        boldText = QtGui.QTextCharFormat()
        boldText.setForeground(QtCore.Qt.darkCyan)
        boldText.setFontWeight(QtGui.QFont.Bold)

        gitshow='git show ' + self.sha1[index]
        output = os.popen(gitshow);
        for line in output:
            line=line.strip('\n')
            if len(line) == 0:
                cursor.insertText(line, textFormat)
            elif line[0]  == '-':
                cursor.insertText(line, greenText)
            elif line[0] == '+':
                cursor.insertText(line, redText)
            elif line[0] == '@':
                cursor.insertText(line, blueText)
            elif line[0] == 'd':
                cursor.insertText(line, boldText)
            else:
                cursor.insertText(line, textFormat)
            cursor.insertBlock()




    def about(self):
        QtGui.QMessageBox.about(self, "My Git Gui",
                "This is a Simple git gui, just for myself requirement "
                "If you useing this tools and have any question, pls contract to zhenjun85@qq.com")

    def createActions(self):

        self.quitAct = QtGui.QAction("&Quit", self, shortcut="Ctrl+Q",
                statusTip="Quit the application", triggered=self.close)

        self.aboutAct = QtGui.QAction("&About", self,
                statusTip="Show the application's About box",
                triggered=self.about)

        self.aboutQtAct = QtGui.QAction("About &Qt", self,
                statusTip="Show the Qt library's About box",
                triggered=QtGui.qApp.aboutQt)

    def createMenus(self):
        self.fileMenu = self.menuBar().addMenu("&File")
        self.fileMenu.addSeparator()
        self.fileMenu.addAction(self.quitAct)

        self.helpMenu = self.menuBar().addMenu("&Help")
        self.helpMenu.addAction(self.aboutAct)
        self.helpMenu.addAction(self.aboutQtAct)


    def createDockWindows(self):

        dock = QtGui.QDockWidget("Git Log Info", self)
        self.paragraphsList = QtGui.QListWidget(dock)
        self.paragraphsList.addItems(self.info)
        dock.setWidget(self.paragraphsList)
        self.addDockWidget(QtCore.Qt.LeftDockWidgetArea, dock)

        self.paragraphsList.currentRowChanged.connect(self.gitLogShow)


if __name__ == '__main__':

    import sys

    app = QtGui.QApplication(sys.argv)
    mainWin = MainWindow()
    mainWin.show()
    sys.exit(app.exec_())
